export { User } from "./user.entity";
export { Product } from "./product.entity";
